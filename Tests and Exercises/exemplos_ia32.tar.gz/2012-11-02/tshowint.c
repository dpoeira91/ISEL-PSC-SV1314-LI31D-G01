#include <stdio.h>

void show_int_bin(int v);

/*
void show_int_bin(int v) {
	if (v < 2)  
		putchar(v + '0');
	else {
		show_int_bin(v >> 1);
		putchar((v & 1) + '0');
	}
}
*/

int main(int argc, char *argv[]) {
	if (argc != 2) {
		printf("usage: showint <num>\n");
		return 1;
	}
 
	show_int_bin(atoi(argv[1]));
	putchar('\n');
	return 0;
}
	
