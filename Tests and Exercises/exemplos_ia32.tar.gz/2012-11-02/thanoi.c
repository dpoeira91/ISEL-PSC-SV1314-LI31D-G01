#include <stdio.h>

void hanoi(int n, char hi, char hf, char ha) {
	if (n>0) {
		 hanoi(n-1, hi,  ha,  hf);
		 printf("%c %c\n", hi, hf );
		 hanoi(n-1,ha,  hf,  hi);
	}
}

int main() {
	hanoi(6, 'A', 'C', 'B');
}
	
