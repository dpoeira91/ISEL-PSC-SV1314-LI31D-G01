/*-------------------------------------------------------------
  count_if test
--------------------------------------------------------------*/

#include <stdio.h>

typedef int boolean;

typedef int (*Predicate)(void *elem, void *ctx);


int count_if(void *seq, size_t nelems, size_t elemSize, Predicate pred, void *ctx);


/*
int count_if(void *seq, size_t nelems, size_t elemSize, Predicate pred, void *ctx) {
	int count=0, i=0;
	char *curr = (char *) seq;
	
	while( i < nelems) {
		if (pred(curr, ctx))
			count++;
		curr += elemSize;
		i++;
	}
	return count;
}
*/


struct range {
	int li, ls;
};

boolean inRange(void *elem, void *ctx) {
	struct range *r = (struct range *) ctx;
	int v = *(int *) elem;
	return v >= r->li && v <= r-> ls;
}

int main() {
	int vals[] = {1, 7, 2, 9, 11, 13, 3, 8, 20 };
	struct range r1 = { 10, 20 };
	const int nvals = sizeof(vals)/sizeof(int);
	
	int res = count_if(vals, nvals, sizeof(int), inRange, &r1);
	printf("%d\n", res);
	return 0;
}
	
	


	
