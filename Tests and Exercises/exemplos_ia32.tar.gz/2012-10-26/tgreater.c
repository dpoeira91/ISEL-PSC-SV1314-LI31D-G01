#include <stdio.h>


int greatern(int *vals, int n);


int main() {
	int vals[] = { 34, 56, 2, -58, 5, 47 };
	const int n = sizeof(vals)/sizeof(int);
	
	printf("maior=%d\n", greatern1(vals, n));
}
	 
		
