#include <stdio.h>

typedef int boolean;

int countequals(int *vals, int n, int ref)  {
	int i, count=0;
	for(i=0; i < n; ++i)
	  if (vals[i] == ref) 
	    count++;
	return count;
}
 
boolean isfive(int v, void *ctx) { return v== 5; }
boolean isequal(int v, void *ctx) { int i = *(int*) ctx; return v== i; }

int countif(int *vals, int n, boolean (*pred)(int, void *), void *ctx )  {
	int i, count=0;
	for(i=0; i < n; ++i)
	  if (pred(vals[i], ctx)) 
	    count++;
	return count;
}

int greatern(int vals[], int n);

int main() {
	int vals[] = { 34, 56, 2, -58, 5, 47, 5 };
	const int n = sizeof(vals)/sizeof(int);
	int ref=5;
		
	printf("count=%d\n", countif(vals, n, isequal, (void *)&ref));
	return 0;
}
	 
		
